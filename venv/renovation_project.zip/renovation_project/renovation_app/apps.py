from django.apps import AppConfig


class RenovationAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'renovation_app'
